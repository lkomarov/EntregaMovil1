echo "******************************************"
echo "COMPILAR APLICACION"
echo "******************************************\n\n"


ionic build
