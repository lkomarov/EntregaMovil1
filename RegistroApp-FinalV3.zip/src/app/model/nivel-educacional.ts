export class NivelEducacional {
  public id: number;
  public nombre: string;

  public constructor() {
      this.id = 1;
      this.nombre = 'Básica Incompleta';
  }

  public setNivelEducacional(id: number, nombre: string): void {
      this.id = id;
      this.nombre = nombre;
  }

  public static getNivelEducacional(id: number, nombre: string): NivelEducacional {
      const nivel = new NivelEducacional();
      nivel.setNivelEducacional(id, nombre);
      return nivel;
  }

  public static getNivelesEducacionales(): NivelEducacional[] {
      return [
          NivelEducacional.getNivelEducacional(1, 'Básica Incompleta'),
          NivelEducacional.getNivelEducacional(2, 'Básica Completa'),
          NivelEducacional.getNivelEducacional(3, 'Media Incompleta'),
          NivelEducacional.getNivelEducacional(4, 'Media Completa'),
          NivelEducacional.getNivelEducacional(5, 'Superior Incompleta'),
          NivelEducacional.getNivelEducacional(6, 'Superior Completa')
      ];
  }

  public static findNivelEducacionalById(id: number): NivelEducacional | undefined {
      return this.getNivelesEducacionales().find(nivel => nivel.id === id);
  }

  public getEducacion(): string {
      return this.id.toString() + ' - ' + this.nombre;
  }
}
