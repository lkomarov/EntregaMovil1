import { Component } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { NivelEducacional } from 'src/app/model/nivel-educacional';
import { Usuario } from 'src/app/model/usuario';


@Component({
  selector: 'app-ingreso',
  templateUrl: 'ingreso.page.html',
  styleUrls: ['ingreso.page.scss']
})
export class IngresoPage {
  public usuario: Usuario;

  constructor(
    private router: Router,
  ) {
    this.usuario = new Usuario('', '', '', '', '', '', '', 
      NivelEducacional.findNivelEducacionalById(1)!, undefined);
  }

  async login() {
    const error = this.usuario.validarUsuario();
    if (error != "" ) {
      this.router.navigate(['/incorrecto']);
    } 
    else {
      const user: Usuario | undefined = Usuario.buscarUsuarioValido(this.usuario.cuenta, this.usuario.password);
      if (user) {
        // Navegar a la página de inicio
        this.router.navigate(['/correcto'], { 
          state: { usuario: user }
        });
      }
    }
  }
} 