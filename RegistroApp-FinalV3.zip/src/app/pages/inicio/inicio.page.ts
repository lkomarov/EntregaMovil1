import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Usuario } from 'src/app/model/usuario';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NivelEducacional } from 'src/app/model/nivel-educacional';
import { AlertController, AnimationController, LoadingController } from '@ionic/angular';
import jsQR, { QRCode } from 'jsqr';


@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss']
})
export class InicioPage implements OnInit, AfterViewInit {
  public segmentValue: string = 'inicio';
  public escaneando = false;
  public datosQR: any = null;
  public loading: HTMLIonLoadingElement | null = null;
  public usuario: Usuario = new Usuario();
  public listaNivelesEducacionales = NivelEducacional.getNivelesEducacionales();
  @ViewChild('video')
  private video!: ElementRef;
  @ViewChild('canvas')
  private canvas!: ElementRef;
  @ViewChild('fileinput')
  private fileinput!: ElementRef;

  @ViewChild('titulo', { read: ElementRef }) itemTitulo!: ElementRef;




  public constructor(
    private animationCtrl: AnimationController,
    private loadingController: LoadingController,
    private alertController: AlertController, 
    private activatedRoute: ActivatedRoute,
    private animationController: AnimationController,
    private router: Router
  ) 
    {
      // Manejo de los parámetros recibidos en la navegación
      this.activatedRoute.queryParams.subscribe(params => {
        const nav = this.router.getCurrentNavigation();
        if (nav) {
          if (nav.extras.state) {
            this.usuario = nav.extras.state['usuario'];
            return;
          }
          // Si no se recibe un usuario válido, redirigir al ingreso
          this.router.navigate(['/ingreso']);
        }
      });
    }

  ngAfterViewInit(): void {
      
  }
  ngOnInit() {
    this.animateTitle();
  }

  animateTitle() {
    const titleElement = document.querySelector('.title-animation');
    if (titleElement) {
      const animation = this.animationCtrl.create()
        .addElement(titleElement)
        .duration(5000)
        .iterations(Infinity)
        .keyframes([
          { offset: 0, transform: 'translateX(-100%)', opacity: '0' },
          { offset: 0.1, transform: 'translateX(0)', opacity: '1' },
          { offset: 0.9, transform: 'translateX(0)', opacity: '1' },
          { offset: 1, transform: 'translateX(100%)', opacity: '0' }
        ]);

      animation.play();
    }
  }

  

  logout() {
    this.router.navigate(['/ingreso']);
  }

  // Función para comenzar el escaneo del QR
  public async comenzarEscaneoQR() {
    const mediaProvider: MediaProvider = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' }
    });
    this.video.nativeElement.srcObject = mediaProvider;
    this.video.nativeElement.setAttribute('playsinline', 'true');
    this.loading = await this.loadingController.create({});
    await this.loading.present();
    this.video.nativeElement.play();
    requestAnimationFrame(this.verificarVideo.bind(this));
  }

  // Verificación y obtención de datos del QR
  public obtenerDatosQR(source?: CanvasImageSource): boolean {
    let w = 0;
    let h = 0;
    if (!source) {
      this.canvas.nativeElement.width = this.video.nativeElement.videoWidth;
      this.canvas.nativeElement.height = this.video.nativeElement.videoHeight;
    }
  
    w = this.canvas.nativeElement.width;
    h = this.canvas.nativeElement.height;
  
    const context: CanvasRenderingContext2D = this.canvas.nativeElement.getContext('2d');
    context.drawImage(source ? source : this.video.nativeElement, 0, 0, w, h);
    const img: ImageData = context.getImageData(0, 0, w, h);
    const qrCode: QRCode | null = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
  
    if (qrCode) {
      this.escaneando = false;
      try {
        this.datosQR = JSON.parse(qrCode.data);
      } catch (error) {
        this.datosQR = qrCode.data;
      }
    }
  
    return this.datosQR !== null && this.datosQR !== '';
  }

  // Verificar el estado del video mientras se escanea
  async verificarVideo() {
    if (this.video.nativeElement.readyState === this.video.nativeElement.HAVE_ENOUGH_DATA) {
      if (this.loading) {
        await this.loading.dismiss();
        this.loading = null;
        this.escaneando = true;
      }
      if (this.obtenerDatosQR()) {
        let stream = this.video.nativeElement.srcObject;
        let tracks = stream.getTracks();
        tracks.forEach((track: { stop: () => any; }) => track.stop());
      } else {
        if (this.escaneando) {
          requestAnimationFrame(this.verificarVideo.bind(this));
        }
      }
    } else {
      requestAnimationFrame(this.verificarVideo.bind(this));
    }
  }

  // Detener el escaneo de QR
  public detenerEscaneoQR(): void {
    this.escaneando = false;
    let stream = this.video.nativeElement.srcObject;
    let tracks = stream.getTracks();
    tracks.forEach((track: { stop: () => any; }) => track.stop());
  }
  public cargarImagenDesdeArchivo(): void {
    this.limpiarDatos();
    this.fileinput.nativeElement.click();
  }
  verificarArchivoConQR(files: FileList | null) {
    if (!files || files.length === 0) {
      console.error("No se ha seleccionado ningún archivo.");
      return;
    }
  
    const file = files[0]; // Obtener el primer archivo
    if (file) {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      // Resto de tu lógica para manejar la imagen
    }
  }
  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.verificarArchivoConQR(input.files);
    }
  }

  public limpiarDatos(): void {
    this.escaneando = false;
    this.datosQR = '';
    this.loading = null;
    (document.getElementById('input-file') as HTMLInputElement).value = '';
  }

  segmentChanged(event: any) {
    this.segmentValue = event.detail.value;
    const navigationExtras: NavigationExtras = {
      state: {
        usuario: this.usuario
      }
    };
    switch(this.segmentValue) {
      case 'miclase':
        this.router.navigate(['/miclase'], navigationExtras);
        break;
      case 'misdatos':
        this.router.navigate(['/misdatos'], navigationExtras);
        break;
      default:
        // Permanece en la página de inicio
        break;
    }
  }

}