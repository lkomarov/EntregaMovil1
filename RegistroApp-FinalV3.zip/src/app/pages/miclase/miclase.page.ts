import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Usuario } from 'src/app/model/usuario';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NivelEducacional } from 'src/app/model/nivel-educacional';
import { AlertController, AnimationController, LoadingController } from '@ionic/angular';
import jsQR, { QRCode } from 'jsqr';

@Component({
  selector: 'app-miclase',
  templateUrl: './miclase.page.html',
  styleUrls: ['./miclase.page.scss'],
})
export class MiclasePage implements OnInit{
public usuario: Usuario = new Usuario();
public segmentValue: string = 'miclase';
public datosQR: any = null;
constructor(
  private animationCtrl: AnimationController,
  private router: Router,
  private activatedRoute: ActivatedRoute,) {
    {
      // Manejo de los parámetros recibidos en la navegación
      this.activatedRoute.queryParams.subscribe(params => {
        const nav = this.router.getCurrentNavigation();
        if (nav) {
          if (nav.extras.state) {
            this.usuario = nav.extras.state['usuario'];
            return;
          }
          // Si no se recibe un usuario válido, redirigir al ingreso
          this.router.navigate(['/ingreso']);
        }
      });
    }
  }

  ngOnInit() {
    this.animateTitle();
  }

  animateTitle() {
    const titleElement = document.querySelector('.title-animation');
    if (titleElement) {
      const animation = this.animationCtrl.create()
        .addElement(titleElement)
        .duration(5000)
        .iterations(Infinity)
        .keyframes([
          { offset: 0, transform: 'translateX(-100%)', opacity: '0' },
          { offset: 0.1, transform: 'translateX(0)', opacity: '1' },
          { offset: 0.9, transform: 'translateX(0)', opacity: '1' },
          { offset: 1, transform: 'translateX(100%)', opacity: '0' }
        ]);

      animation.play();
    }
  }

  logout() {
    this.router.navigate(['/ingreso']);
  }

  segmentChanged(event: any) {
    this.segmentValue = event.detail.value;
    const navigationExtras: NavigationExtras = {
      state: {
        usuario: this.usuario
      }
    };
    switch(this.segmentValue) {
      case 'inicio':
        this.router.navigate(['/inicio'], navigationExtras);
        break;
      case 'misdatos':
        this.router.navigate(['/misdatos'], navigationExtras);
        break;
      default:
        // Permanece en la página de inicio
        break;
    }
  }
}