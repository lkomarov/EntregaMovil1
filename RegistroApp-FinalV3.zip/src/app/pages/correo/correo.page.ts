
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { NivelEducacional } from 'src/app/model/nivel-educacional';
import { Usuario } from 'src/app/model/usuario';
import { AnimationController} from '@ionic/angular';
import { ToastController } from '@ionic/angular';

@Component({
  
  selector: 'app-correo',
  templateUrl: './correo.page.html',
  styleUrls: ['./correo.page.scss'],
})
export class CorreoPage implements OnInit {
  @ViewChild('titulo', { read: ElementRef }) itemTitulo!: ElementRef;


    public usuario: Usuario;

  constructor(
    private router: Router,
    private animationController: AnimationController,
     private toastController: ToastController) 
     {
    this.usuario = new Usuario('', '', '', '', '', '', '', 
      NivelEducacional.findNivelEducacionalById(1)!, undefined);
    this.usuario.cuenta = 'atorres';
    this.usuario.password = '1234';
  }
  public ngAfterViewInit(): void {
    if (this.itemTitulo) {
      const animation = this.animationController
        .create()
        .addElement(this.itemTitulo.nativeElement)
        .iterations(Infinity)
        .duration(6000)
        .fromTo('transform', 'translate(0%)', 'translate(100%)')
        .fromTo('opacity', 0.2, 1);

      animation.play();
    }
    
  }

  public ngOnInit(): void {
    //if (this.usuario.correo !== '') this.ingresar();
  }

  public ingresar(): void {
    if (this.usuario) {

      if(!this.validarUsuario(this.usuario)) return;
      
      const usu: Usuario | undefined = Usuario.buscarUsuarioValido(this.usuario.cuenta, this.usuario.password);
(
        this.usuario.cuenta, this.usuario.password);

      if (usu) {
        const navigationExtras: NavigationExtras = {
          state: {
            usuario: usu
          }
        };
        this.router.navigate(['/pregunta'], navigationExtras); // Navegamos hacia el Inicio y enviamos la información extra
      }
    }
  }

  public validarUsuario(usuario: Usuario): boolean {
    const mensajeError = usuario.validarUsuario();
    if (mensajeError) {
      this.mostrarMensaje(mensajeError);
      return false
    }
    return true;
  }

  async mostrarMensaje(mensaje: string, duracion?: number) {
    const toast = await this.toastController.create({
        message: mensaje,
        duration: duracion? duracion: 2000
      });
    toast.present();
  }

}



