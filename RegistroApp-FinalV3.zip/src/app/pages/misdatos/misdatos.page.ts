import { MisdatosPageModule } from './misdatos.module';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { Usuario } from 'src/app/model/usuario';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { NivelEducacional } from 'src/app/model/nivel-educacional';
import { AlertController, AnimationController, NavController, NavParams, ToastController } from '@ionic/angular';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { NativeDateAdapter, DateAdapter } from '@angular/material/core';


@Component({
  selector: 'app-misdatos',
  templateUrl: './misdatos.page.html',
  styleUrls: ['./misdatos.page.scss'],
  providers: [
    { provide: DateAdapter, useClass: NativeDateAdapter },
    MatDatepickerModule,
    MatInputModule,
    MatFormFieldModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MisdatosPage implements OnInit {

  public segmentValue: string = 'misdatos';
  public usuario: Usuario = new Usuario();
  public listaNivelesEducacionales = NivelEducacional.getNivelesEducacionales();

constructor(
  private animationCtrl: AnimationController,
  private router: Router,
  private activatedRoute: ActivatedRoute,
  private toastController: ToastController
) {
    // Manejo de los parámetros recibidos en la navegación
    this.activatedRoute.queryParams.subscribe(params => {
      const nav = this.router.getCurrentNavigation();
      if (nav) {
        if (nav.extras.state) {
          this.usuario = nav.extras.state['usuario'];
          return;
        }
        // Si no se recibe un usuario válido, redirigir al ingreso
        this.router.navigate(['/ingreso']);
      }
    });
  }

  ngOnInit() {
    this.animateTitle();
  }

  animateTitle() {
    const titleElement = document.querySelector('.title-animation');
    if (titleElement) {
      const animation = this.animationCtrl.create()
        .addElement(titleElement)
        .duration(5000)
        .iterations(Infinity)
        .keyframes([
          { offset: 0, transform: 'translateX(-100%)', opacity: '0' },
          { offset: 0.1, transform: 'translateX(0)', opacity: '1' },
          { offset: 0.9, transform: 'translateX(0)', opacity: '1' },
          { offset: 1, transform: 'translateX(100%)', opacity: '0' }
        ]);

      animation.play();
    }
  }

  logout() {
    this.router.navigate(['/ingreso']);
  }


  guardarDatos() {
      const navigationExtras: NavigationExtras = {
        state: {
          usuario: this.usuario
        }
      };
      this.router.navigate(['/misdatos'], navigationExtras);
      this.mostrarMensajeEmergente('Datos guardados con éxito');
    }

    async mostrarMensajeEmergente(mensaje: string, duracion?: number) {
      const toast = await this.toastController.create({
          message: mensaje,
          duration: duracion? duracion: 2000
        });
      toast.present();
    }

  segmentChanged(event: any) {
    this.segmentValue = event.detail.value;
    const navigationExtras: NavigationExtras = {
      state: {
        usuario: this.usuario
      }
    };
    switch(this.segmentValue) {
      case 'inicio':
        this.router.navigate(['/inicio'], navigationExtras);
        break;
      case 'miclase':
        this.router.navigate(['/miclase'], navigationExtras);
        break;
      default:
        // Permanece en la página de inicio
        break;
    }
  }
}